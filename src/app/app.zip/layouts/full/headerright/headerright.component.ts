import { Component, AfterViewInit } from '@angular/core';
import { PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';
import { CookieService } from "angular2-cookie/core";

import { Router } from '@angular/router';
import { HeaderService } from '../header/header.service';


@Component({
  selector: 'app-headerright',
  templateUrl: './headerright.component.html',
  styleUrls: []
})
export class AppHeaderrightComponent implements AfterViewInit  {   
  constructor(private _cookieService: CookieService,  private router: Router, private headerService: HeaderService) {}
 ngAfterViewInit() {
     this.getClinics();
  }
   public clinicsData:any[] = [];
  public config: PerfectScrollbarConfigInterface = {};
   private getClinics() { 
  this.headerService.getClinics().subscribe((res) => {
       if(res.message == 'success'){
        this.clinicsData = res.data;
       }
    }, error => {
     // this.warningMessage = "Please Provide Valid Inputs!";
    }    
    );

  }
/*  logout() {
      this.headerrightService.logout(this._cookieService.get("userid")).subscribe((res) => {
       console.log(res);
       if(res.message == 'success'){
        this._cookieService.put("username",'');
        this._cookieService.put("email", '');
        this._cookieService.put("token", '');
        this._cookieService.put("userid", '');

        this.router.navigate(['/login']);
       }
    }, error => {
    }    
    );
  }*/
  
}
