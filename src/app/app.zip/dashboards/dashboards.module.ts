import 'hammerjs';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { HttpModule } from '@angular/http';
import { CommonModule, DatePipe } from '@angular/common';

import { DemoMaterialModule } from '../demo-material-module';
import { CdkTableModule } from '@angular/cdk/table';
import { ChartsModule } from 'ng2-charts';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FlexLayoutModule } from '@angular/flex-layout';

import { DashboardsRoutes } from './dashboards.routing';
import { ChartistModule } from 'ng-chartist';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { ClinicianAnalysisService } from './cliniciananalysis/cliniciananalysis.service';
import { ClinicianAnalysisComponent } from './cliniciananalysis/cliniciananalysis.component';
import { ClinicianProceeduresService } from './clinicianproceedures/clinicianproceedures.service';
import { ClinicianProceeduresComponent } from './clinicianproceedures/clinicianproceedures.component';
import { FinancesService } from './finances/finances.service';
import { FinancesComponent } from './finances/finances.component';
import { DentistService } from '../dentist/dentist.service';
import { NgxGaugeModule } from 'ngx-gauge';
import { NgxDaterangepickerMd } from 'ngx-daterangepicker-material';
import {MatButtonToggleModule, MatIconModule} from '@angular/material';
import { AppHeaderrightComponent } from '../layouts/full/headerright/headerright.component';

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(DashboardsRoutes),
    DemoMaterialModule,
    HttpModule,
    FormsModule,
    ReactiveFormsModule,
    FlexLayoutModule,
    CdkTableModule,
    ChartistModule,
    ChartsModule,
    NgxChartsModule,
    NgxGaugeModule,
     NgxDaterangepickerMd.forRoot(),
     MatButtonToggleModule, MatIconModule
  ],
  providers: [ ClinicianAnalysisService, ClinicianProceeduresService, FinancesService, DentistService,DatePipe],
  declarations: [ClinicianAnalysisComponent, ClinicianProceeduresComponent, FinancesComponent, AppHeaderrightComponent]
})
export class DashboardsModule {}
