import * as $ from 'jquery';
import { Component, AfterViewInit, SecurityContext, ViewEncapsulation, OnInit , ViewChild,ElementRef } from '@angular/core';
import { FinancesService } from './finances.service';
import { DentistService } from '../../dentist/dentist.service';

import * as frLocale from 'date-fns/locale/fr';
import { DatePipe } from '@angular/common';
import {
  FormControl,
  FormGroupDirective,
  NgForm,
  Validators
} from '@angular/forms';
import { ActivatedRoute } from "@angular/router";
import 'chartjs-plugin-style';
import { HeaderService } from '../../layouts/full/header/header.service';
import { Http, Headers, RequestOptions } from '@angular/http';
import { AppHeaderrightComponent } from '../../layouts/full/headerright/headerright.component';
import {CommonModule} from '@angular/common';
export interface Dentist {
  providerId: string;
  name: string;
}

@Component({
  templateUrl: './finances.component.html'
})
export class FinancesComponent implements AfterViewInit {
    @ViewChild("myCanvas") canvas: ElementRef;
  lineChartColors;
  doughnutChartColors ;
  subtitle: string;
   public clinic_id:any ={};
   public dentistCount:any ={};
   public netProfitIcon:string ='';
   public netProfitPercentIcon:string ='';
   public netProfitPmsIcon:string ='';

    public netProfitVal:any= 0;
   public netProfitPercentVal:any =0;
   public netProfitPmsVal:any =0;
  


  constructor(private financesService: FinancesService, private dentistService: DentistService, private datePipe: DatePipe, private route: ActivatedRoute,  private headerService: HeaderService){
  }
  private warningMessage: string;

  ngAfterViewInit() {
 this.route.params.subscribe(params => {
    this.clinic_id = this.route.snapshot.paramMap.get("id");
        this.filterDate('m');
        this.getDentists(); 
        this.loadDentist('all');
    $('.external_dentist').val('all');
  $('#title').html('Finances');        
     });
 let gradient = this.canvas.nativeElement.getContext('2d').createLinearGradient(0, 0, 0, 400);
      gradient.addColorStop(0, 'rgba(25, 179,148,0.8)');
      gradient.addColorStop(1, 'rgba(22, 82, 141, 0.6)');
      let gradient1 = this.canvas.nativeElement.getContext('2d').createLinearGradient(0, 0, 0, 100);
      gradient1.addColorStop(1, 'rgba(12, 209,169,0.8)');
      gradient1.addColorStop(0,  'rgba(22, 82, 141, 0.8)');
      let gradient2 = this.canvas.nativeElement.getContext('2d').createLinearGradient(0, 0, 0, 100);
      gradient2.addColorStop(1, 'rgba(59, 227,193,0.8)');
      gradient2.addColorStop(0,  'rgba(22, 82, 141, 0.8)');
      let gradient3 = this.canvas.nativeElement.getContext('2d').createLinearGradient(0, 0, 0, 100);
      gradient3.addColorStop(1, 'rgba(94, 232,205,0.8)');
      gradient3.addColorStop(0,  'rgba(22, 82, 141, 0.9)');
      let gradient4 = this.canvas.nativeElement.getContext('2d').createLinearGradient(0, 0, 0, 100);
      gradient4.addColorStop(1, 'rgba(148, 240,221,0.8)');
      gradient4.addColorStop(0,  'rgba(22, 82, 141, 0.8)');
      let gradient5 = this.canvas.nativeElement.getContext('2d').createLinearGradient(0, 0, 0, 100);
      gradient5.addColorStop(1, 'rgba(201, 247,238,0.8)');
      gradient5.addColorStop(0,  'rgba(22, 82, 141, 0.8)');
this.doughnutChartColors = [{backgroundColor: [gradient5,gradient4,gradient3,gradient2,gradient1,gradient]}];

  }

  public date =new Date();

  dentists: Dentist[] = [
   { providerId: 'all', name: 'All Dentists' },
  ];
    public stackedChartOptions: any = {
    scaleShowVerticalLines: false,
           responsive: true,
    maintainAspectRatio: false,
    barThickness: 10,
      animation: {
        duration: 1500,
        easing: 'easeOutSine'
      },
    scales: {
          xAxes: [{ 
            stacked: true, 
            ticks: {
                autoSkip: false
            }
            }],
          yAxes: [{ 
            stacked: true, 
            ticks: {
              
            }, 
            }],
        }
  };
    public pieChartOptions: any = {
    responsive: true,
    maintainAspectRatio: false,
    legend: {
            display: false
         }
  };
   public barChartOptions: any = {
    scaleShowVerticalLines: false,
           responsive: true,
    maintainAspectRatio: false,
      animation: {
        duration: 1500,
        easing: 'easeOutSine'
      },
    barThickness: 10,
        scales: {
          xAxes: [{ 
            ticks: {
                  autoSkip: false
              }
            }],
          yAxes: [{  
            ticks: {
             
            }, 
            }],
        },
         legend: {
        position: 'top',
        onClick: function(e, legendItem) {
          var index = legendItem.datasetIndex;
          var ci = this.chart; 
          if(index ==0)
          {
                (<HTMLElement>document.querySelector('.predicted1')).style.display = 'flex';
                
                (<HTMLElement>document.querySelector('.predicted2')).style.display = 'none';
                (<HTMLElement>document.querySelector('.predicted3')).style.display = 'none';

                ci.getDatasetMeta(1).hidden = true;
                ci.getDatasetMeta(2).hidden = true;
                ci.getDatasetMeta(index).hidden = false;
          }
          else if(index== 1) {
            (<HTMLElement>document.querySelector('.predicted1')).style.display = 'none';
                (<HTMLElement>document.querySelector('.predicted2')).style.display = 'flex';

                (<HTMLElement>document.querySelector('.predicted3')).style.display = 'none';
                ci.getDatasetMeta(0).hidden = true;
                ci.getDatasetMeta(2).hidden = true;
                ci.getDatasetMeta(index).hidden = false;
          } 
          else if(index== 2) {
            (<HTMLElement>document.querySelector('.predicted1')).style.display = 'none';
                (<HTMLElement>document.querySelector('.predicted2')).style.display = 'none';
                (<HTMLElement>document.querySelector('.predicted3')).style.display = 'flex';

                ci.getDatasetMeta(0).hidden = true;
                ci.getDatasetMeta(1).hidden = true;
                ci.getDatasetMeta(index).hidden = false;
          }
          ci.update();
        },
      }     
          };


  public proceedureChartOptions: any = {
    scaleShowVerticalLines: false,
           responsive: true,
    maintainAspectRatio: false,
    barThickness: 10,
      animation: {
        duration: 1500,
        easing: 'easeOutSine'
      },
        scales: {
          xAxes: [{ 
            ticks: {
                  autoSkip: false
              }
            }],
          yAxes: [{  
            ticks: {
             
            }, 
            }],
        },
         legend: {
        position: 'top',
      },
      tooltips: {
  callbacks: {
    label: function(tooltipItems, data) { 
      return data.datasets[tooltipItems.datasetIndex].label+": $"+tooltipItems.yLabel;
    }
  }
},        
  };

  public selectedDentist: string;
  public predicted1: boolean = true;
  public predicted2: boolean = false;
  public predicted3: boolean = false;
  public showInternal: boolean = true;
  public showExternal: boolean = false;
  public showCombined: boolean = false;
  public stackedChartColors: Array<any> = [
    { backgroundColor: '#76F2E5' },
    { backgroundColor: '#6BE6EF' },
    { backgroundColor: '#68D8D6' },
    { backgroundColor: '#3DCCC7' },
    { backgroundColor: '#68FFF9' },
    { backgroundColor: '#07BEB8' }
  ];
  public stackedChartType = 'bar';
  public stackedChartLegend = true;

  //labels
  public stackedChartLabels: string[] = [];  
  public stackedChartLabels1: string[] = [];

  public predictedChartLabels: string[] = [];
  public predictedChartLabels1: string[] = [];

  public proceedureChartLabels: string[] = [];
  public proceedureChartLabels1: string[] = [];
  public proceedureDentistChartLabels: string[] = [];
  //data
  public stackedChartData: any[] = [
    {data: [], label: 'Crowns',  shadowOffsetX: 3,
            shadowOffsetY: 3,
            shadowBlur: 5,
            shadowColor: 'rgba(0, 0, 0, 0.5)',
            pointBevelWidth: 2,
            pointBevelHighlightColor: 'rgba(255, 255, 255, 0.75)',
            pointBevelShadowColor: 'rgba(0, 0, 0, 0.5)',
            pointShadowOffsetX: 3,
            pointShadowOffsetY: 3,
            pointShadowBlur: 10,
            pointShadowColor: 'rgba(0, 0, 0, 0.5)',
            backgroundOverlayMode: 'multiply'},
    {data: [], label: 'Splints ' ,  shadowOffsetX: 3,
            shadowOffsetY: 3,
            shadowBlur: 5,
            shadowColor: 'rgba(0, 0, 0, 0.5)',
            pointBevelWidth: 2,
            pointBevelHighlightColor: 'rgba(255, 255, 255, 0.75)',
            pointBevelShadowColor: 'rgba(0, 0, 0, 0.5)',
            pointShadowOffsetX: 3,
            pointShadowOffsetY: 3,
            pointShadowBlur: 10,
            pointShadowColor: 'rgba(0, 0, 0, 0.5)',
            backgroundOverlayMode: 'multiply'},
    {data: [], label: 'Root Canals' ,  shadowOffsetX: 3,
            shadowOffsetY: 3,
            shadowBlur: 5,
            shadowColor: 'rgba(0, 0, 0, 0.5)',
            pointBevelWidth: 2,
            pointBevelHighlightColor: 'rgba(255, 255, 255, 0.75)',
            pointBevelShadowColor: 'rgba(0, 0, 0, 0.5)',
            pointShadowOffsetX: 3,
            pointShadowOffsetY: 3,
            pointShadowBlur: 10,
            pointShadowColor: 'rgba(0, 0, 0, 0.5)',
            backgroundOverlayMode: 'multiply'},
    {data: [], label: 'Perio Charts' ,  shadowOffsetX: 3,
            shadowOffsetY: 3,
            shadowBlur: 5,
            shadowColor: 'rgba(0, 0, 0, 0.5)',
            pointBevelWidth: 2,
            pointBevelHighlightColor: 'rgba(255, 255, 255, 0.75)',
            pointBevelShadowColor: 'rgba(0, 0, 0, 0.5)',
            pointShadowOffsetX: 3,
            pointShadowOffsetY: 3,
            pointShadowBlur: 10,
            pointShadowColor: 'rgba(0, 0, 0, 0.5)',
            backgroundOverlayMode: 'multiply'},
    {data: [], label: 'Surgical Extractions' ,  shadowOffsetX: 3,
            shadowOffsetY: 3,
            shadowBlur: 5,
            shadowColor: 'rgba(0, 0, 0, 0.5)',
            pointBevelWidth: 2,
            pointBevelHighlightColor: 'rgba(255, 255, 255, 0.75)',
            pointBevelShadowColor: 'rgba(0, 0, 0, 0.5)',
            pointShadowOffsetX: 3,
            pointShadowOffsetY: 3,
            pointShadowBlur: 10,
            pointShadowColor: 'rgba(0, 0, 0, 0.5)',
            backgroundOverlayMode: 'multiply'}  ];

  public stackedChartData1: any[] = [];
  public stackedChartData2: any[] = [];
  public stackedChartData3: any[] = [];
  public stackedChartData4: any[] = [];
  public stackedChartData5: any[] = [];

  public predictedChartData: any[] = [
    {data: [], label: 'Crown to Large Filling',  shadowOffsetX: 3,
            shadowOffsetY: 3,
            shadowBlur: 5,
            shadowColor: 'rgba(0, 0, 0, 0.5)',
            pointBevelWidth: 2,
            pointBevelHighlightColor: 'rgba(255, 255, 255, 0.75)',
            pointBevelShadowColor: 'rgba(0, 0, 0, 0.5)',
            pointShadowOffsetX: 3,
            pointShadowOffsetY: 3,
            pointShadowBlur: 10,
            pointShadowColor: 'rgba(0, 0, 0, 0.5)',
            backgroundOverlayMode: 'multiply'},
    {data: [], label: 'Extraction to RCT',hidden: true,  shadowOffsetX: 3,
            shadowOffsetY: 3,
            shadowBlur: 5,
            shadowColor: 'rgba(0, 0, 0, 0.5)',
            pointBevelWidth: 2,
            pointBevelHighlightColor: 'rgba(255, 255, 255, 0.75)',
            pointBevelShadowColor: 'rgba(0, 0, 0, 0.5)',
            pointShadowOffsetX: 3,
            pointShadowOffsetY: 3,
            pointShadowBlur: 10,
            pointShadowColor: 'rgba(0, 0, 0, 0.5)',
            backgroundOverlayMode: 'multiply'},
    {data: [], label: 'RCT Conversion',hidden: true,  shadowOffsetX: 3,
            shadowOffsetY: 3,
            shadowBlur: 5,
            shadowColor: 'rgba(0, 0, 0, 0.5)',
            pointBevelWidth: 2,
            pointBevelHighlightColor: 'rgba(255, 255, 255, 0.75)',
            pointBevelShadowColor: 'rgba(0, 0, 0, 0.5)',
            pointShadowOffsetX: 3,
            pointShadowOffsetY: 3,
            pointShadowBlur: 10,
            pointShadowColor: 'rgba(0, 0, 0, 0.5)',
            backgroundOverlayMode: 'multiply'},

    ];

  public predictedChartData1: any[] = [];  
  public predictedChartData2: any[] = [];  
  public predictedChartData3: any[] = [];  

  public proceedureChartType = 'horizontalBar';

  public proceedureChartData: any[] = [
    {data: [], label: 'Total Revenue of Clinician Per Procedure',  shadowOffsetX: 3,
            shadowOffsetY: 3,
            shadowBlur: 5,
            shadowColor: 'rgba(0, 0, 0, 0.5)',
            pointBevelWidth: 2,
            pointBevelHighlightColor: 'rgba(255, 255, 255, 0.75)',
            pointBevelShadowColor: 'rgba(0, 0, 0, 0.5)',
            pointShadowOffsetX: 3,
            pointShadowOffsetY: 3,
            pointShadowBlur: 10,
            pointShadowColor: 'rgba(0, 0, 0, 0.5)',
            backgroundOverlayMode: 'multiply'}
    ];
  public proceedureDentistChartData: any[] = [
    {data: [], label: 'Total Revenue of Clinician Per Procedure',  shadowOffsetX: 3,
            shadowOffsetY: 3,
            shadowBlur: 5,
            shadowColor: 'rgba(0, 0, 0, 0.5)',
            pointBevelWidth: 2,
            pointBevelHighlightColor: 'rgba(255, 255, 255, 0.75)',
            pointBevelShadowColor: 'rgba(0, 0, 0, 0.5)',
            pointShadowOffsetX: 3,
            pointShadowOffsetY: 3,
            pointShadowBlur: 10,
            pointShadowColor: 'rgba(0, 0, 0, 0.5)',
            backgroundOverlayMode: 'multiply'}
    ];
  public proceedureChartData1: any[] = []; 
 

  //Total  
  public predictedTotal1 = 0;
  public predictedTotal2 = 0;
  public predictedTotal3 = 0;

  public predictedTotalAverage1 = 0;
  public predictedTotalAverage2 = 0;
  public predictedTotalAverage3 = 0;

  public pieChartTotal = 0;

  // Pie
  public pieChartLabels: string[] = [
  ];
  public pieChartData: number[] = [];
  public pieChartType = 'doughnut';
  public pieChartDatares: number[] = [];

  public pieChartLabelsres: string[] = [
  ];

  public productionChartTotal = 0;

  // production
  public productionChartLabels: string[] = [
  ];
  public productionChartData: number[] = [];
  public productionChartType = 'doughnut';
  public productionChartDatares: number[] = [];

  public productionChartLabelsres: string[] = [
  ];
   public totalDiscountChartTotal = 0;

  // totalDiscount
  public totalDiscountChartLabels: string[] = [
  ];
  public totalDiscountChartData: number[] = [];
  public totalDiscountChartType = 'doughnut';
  public totalDiscountChartDatares: number[] = [];

  public totalDiscountChartLabelsres: string[] = [
  ];

   public totalOverdueAccount = 0;

  public totalOverdueAccountLabels: string[] = [
  ];
  public totalOverdueAccountData: number[] = [];
  public totalOverdueAccountres: number[] = [];

  public totalOverdueAccountLabelsres: string[] = [];

  public itemPredictedChartData: any[] = [
    {data: [10,1,5], label: 'Items Predictor Analysis ',  shadowOffsetX: 3,
            shadowOffsetY: 2,
            shadowBlur: 3,
            shadowColor: 'rgba(0, 0, 0, 0.3)',
            pointBevelWidth: 2,
            pointBevelHighlightColor: 'rgba(255, 255, 255, 0.75)',
            pointBevelShadowColor: 'rgba(0, 0, 0, 0.3)',
            pointShadowOffsetX: 3,
            pointShadowOffsetY: 3,
            pointShadowBlur: 10,
            pointShadowColor: 'rgba(0, 0, 0, 0.3)',
            backgroundOverlayMode: 'multiply'}

    ];
        
  public itemPredictedChartData1: any[] = [];  

  public itemPredictedChartLabels: string[] = [];

  // events
  public chartClicked(e: any): void {
    console.log(e);
  }

  public chartHovered(e: any): void {
    console.log(e);
  }
  public  gaugeType = "arch";
  public  gaugeValue = '';
  public  totalProductionLabel = "";
  public  gaugeThick = "20";
  public  foregroundColor= "rgba(0, 150, 136,0.5)";
  public  cap= "round";
  public  size = "250"
  public  totalProductionVal:any = 10;
  public  gaugeValuePredicted1 = 0;
  public  gaugeValuePredicted = 0;

  public  gaugeValuePredicted2 = 0;

  public  gaugeValuePredicted3 = 0;
  public  gaugeLabelPredicted = "";
  public predictedDentistTotal = 0;
  public gaugePrependText ='$';
  public startDate ='';
  public endDate = '';
  public collectionAppend ='%';

  public  collectionPercentage = 0;
  public  productionVal = 0;

  public  collectionVal = 0;
 private loadDentist(newValue) {
  if(newValue == 'all') {
    $(".trend_toggle").hide();
    this.netProfit();
    this.netProfitPercent();
    this.netProfitPms();
    this.categoryExpenses();
    this.finProductionByClinician();
    this.finTotalDiscounts();
    this.finTotalProduction();
    this.finCollection();
    this.finProductionPerVisit();
    this.finOverdueAccounts();
/*
    (<HTMLElement>document.querySelector('.treatmentPlanSingle')).style.display = 'none';
    (<HTMLElement>document.querySelector('.treatmentPlan')).style.display = 'block';

    (<HTMLElement>document.querySelector('.noPatientsSingle')).style.display = 'none';
    (<HTMLElement>document.querySelector('.noPatients')).style.display = 'block';*/
  }
  else {
    $(".trend_toggle").show();
    this.selectedDentist = newValue;
 //   this.buildChartDentist();
    (<HTMLElement>document.querySelector('.itemsPredictorSingle')).style.display = 'block';
    (<HTMLElement>document.querySelector('.itemsPredictor')).style.display = 'none';

  //  this.buildChartPredictorDentist();
    (<HTMLElement>document.querySelector('.ratioPredictorSingle')).style.display = 'block';
    (<HTMLElement>document.querySelector('.ratioPredictor')).style.display = 'none';

 //   this.buildChartProceedureDentist();
    (<HTMLElement>document.querySelector('.revenueProceedureSingle')).style.display = 'block';
    (<HTMLElement>document.querySelector('.revenueProceedure')).style.display = 'none';
 //   this.buildChartReferralDentist();
/*    this.buildChartTreatmentDentist();
    (<HTMLElement>document.querySelector('.treatmentPlanSingle')).style.display = 'block';
    (<HTMLElement>document.querySelector('.treatmentPlan')).style.display = 'none';

    this.buildChartNopatientsDentist();
    (<HTMLElement>document.querySelector('.noPatientsSingle')).style.display = 'block';
    (<HTMLElement>document.querySelector('.noPatients')).style.display = 'none';*/
  }

  }

  //netProfit
  private netProfit() {

    var user_id;
    var clinic_id;
  this.financesService.NetProfit(this.clinic_id,this.startDate,this.endDate).subscribe((data) => {
       if(data.message == 'success'){
        this.netProfitVal = data.data.total_net_profit;   
        if(Math.sign(this.netProfitVal)===1)
        this.netProfitIcon = "up";
        else
        this.netProfitIcon = "down";
             
        this.netProfitVal = Math.abs(this.netProfitVal).toFixed(2); 

       }
    }, error => {
      this.warningMessage = "Please Provide Valid Inputs!";
 
    }
    );
  }
    //netProfit
  private netProfitPercent() {

    var user_id;
    var clinic_id;
  this.financesService.NetProfitPercent(this.clinic_id,this.startDate,this.endDate).subscribe((data) => {
       if(data.message == 'success'){
        this.netProfitPercentVal = data.data;      
        if(this.netProfitPercentVal>0)
        this.netProfitPercentIcon = "up";
        else
        this.netProfitPercentIcon = "down";
        this.netProfitPercentVal = Math.abs(data.data).toFixed(2);      

       }
    }, error => {
      this.warningMessage = "Please Provide Valid Inputs!";
 
    }
    );
  }
    //netProfit
  private netProfitPms() {

    var user_id;
    var clinic_id;
  this.financesService.NetProfitPms(this.clinic_id,this.startDate,this.endDate).subscribe((data) => {
       if(data.message == 'success'){
        this.netProfitPmsVal = data.data;      
        if(this.netProfitPmsVal>0)
        this.netProfitPmsIcon = "up";
        else
        this.netProfitPmsIcon = "down";
        this.netProfitPmsVal = Math.abs(data.data).toFixed(2);      

       }
    }, error => {
      this.warningMessage = "Please Provide Valid Inputs!";
 
    }
    );
  }
      //expenses
  private categoryExpenses() {

    var user_id;
    var clinic_id;
  this.financesService.categoryExpenses(this.clinic_id,this.startDate,this.endDate).subscribe((data) => {
       if(data.message == 'success'){
                  this.pieChartDatares = [];
        data.data.forEach(res => {
           this.pieChartDatares.push(res.expenses);
           this.pieChartLabelsres.push(res.meta_key);
           this.pieChartTotal = this.pieChartTotal + parseInt(res.expenses);
 });

       this.pieChartData = this.pieChartDatares;
       this.pieChartLabels = this.pieChartLabelsres;
       }
    }, error => {
      this.warningMessage = "Please Provide Valid Inputs!";
 
    }
    );
  }

  //finProductionByClinician
  private finProductionByClinician() {

    var user_id;
    var clinic_id;
    this.productionChartDatares= [];
           this.productionChartLabelsres =[];
           this.productionChartTotal = 0;
  this.financesService.finProductionByClinician(this.clinic_id,this.startDate,this.endDate).subscribe((data) => {
       if(data.message == 'success'){
                  this.productionChartDatares = [];
        data.data.forEach(res => {
           this.productionChartDatares.push((res.percent).toFixed(2));
           this.productionChartLabelsres.push(res.name);
           this.productionChartTotal = this.productionChartTotal + parseInt(res.expenses);
 });

       this.productionChartData = this.productionChartDatares;
       this.productionChartLabels = this.productionChartLabelsres;
       }
    }, error => {
      this.warningMessage = "Please Provide Valid Inputs!";
 
    }
    );
  }

    //finProductionByClinician
  private finTotalDiscounts() {

    var user_id;
    var clinic_id;
     this.totalDiscountChartDatares =[];
           this.totalDiscountChartLabelsres =[];
           this.totalDiscountChartTotal = 0;
  this.financesService.finTotalDiscounts(this.clinic_id,this.startDate,this.endDate).subscribe((data) => {
       if(data.message == 'success'){
                  this.totalDiscountChartDatares = [];
                   this.totalDiscountChartTotal = 0;
        data.data.total_production_by_provider.forEach(res => {
           this.totalDiscountChartDatares.push(res.total);
           this.totalDiscountChartLabelsres.push(res.name);
           this.totalDiscountChartTotal = this.totalDiscountChartTotal + parseInt(res.total);
 });
       this.totalDiscountChartData = this.totalDiscountChartDatares;
       this.totalDiscountChartLabels = this.totalDiscountChartLabelsres;
       }
    }, error => {
      this.warningMessage = "Please Provide Valid Inputs!";
 
    }
    );
  }


    //finTotalProduction
  private finTotalProduction() {

    var user_id;
    var clinic_id;
  this.financesService.finTotalProduction(this.clinic_id,this.startDate,this.endDate).subscribe((data) => {
       if(data.message == 'success'){
        this.totalProductionVal = data.data[0].total;      
        this.totalProductionLabel = data.data[0].name;      
       }
    }, error => {
      this.warningMessage = "Please Provide Valid Inputs!";
 
    }
    );
  }

      //Collection
  private finCollection() {

    var user_id;
    var clinic_id;
  this.financesService.finCollection(this.clinic_id,this.startDate,this.endDate).subscribe((data) => {
       if(data.message == 'success'){
        this.collectionVal = (data.data.paym_total).toFixed(2);      
        this.collectionPercentage = (data.data.percent).toFixed(2);      
       }
    }, error => {
      this.warningMessage = "Please Provide Valid Inputs!";
 
    }
    );
  }
        //finProductionPerVisit
  private finProductionPerVisit() {

    var user_id;
    var clinic_id;
  this.financesService.finProductionPerVisit(this.clinic_id,this.startDate,this.endDate).subscribe((data) => {
       if(data.message == 'success'){
        this.productionVal = data.data.toFixed(2);      
       }
    }, error => {
      this.warningMessage = "Please Provide Valid Inputs!";
 
    }
    );
  }

          //finOverdueAccounts
  private finOverdueAccounts() {

    var user_id;
    var clinic_id;
     this.totalOverdueAccountres =[];
           this.totalOverdueAccountLabelsres = [];
  this.financesService.finOverdueAccounts(this.clinic_id,this.startDate,this.endDate).subscribe((data) => {
       if(data.message == 'success'){
        data.data.forEach(res => {
           this.totalOverdueAccountres.push(res.overdue);
           this.totalOverdueAccountLabelsres.push(res.label);
                  });
           this.totalOverdueAccount = data.total;

       this.totalOverdueAccountData = this.totalOverdueAccountres;
       this.totalOverdueAccountLabels = this.totalOverdueAccountLabelsres;     
       console.log(this.totalOverdueAccountData + " "+ this.totalOverdueAccountLabels);
       }
    }, error => {
      this.warningMessage = "Please Provide Valid Inputs!";
 
    }
    );
  }


  // Filter By Date
  filterDate(duration) {
     $('.customRange').css('display','none');

    if(duration == 'w') {
      const now = new Date();
       var first = now.getDate() - now.getDay();
       var last = first +6; 
       this.startDate = this.datePipe.transform(new Date(now.setDate(first)).toUTCString(), 'yyyy-MM-dd');
       this.endDate = this.datePipe.transform(new Date(now.setDate(last)).toUTCString(), 'yyyy-MM-dd');
    this.loadDentist('all');


    }
    else if (duration == 'm') {
      var date = new Date();
      this.startDate = this.datePipe.transform(new Date(date.getFullYear(), date.getMonth(), 1), 'yyyy-MM-dd');
      this.endDate = this.datePipe.transform(new Date(date.getFullYear(), date.getMonth() + 1, 0), 'yyyy-MM-dd');
    this.loadDentist('all');
   
    }
    else if (duration == 'q') {
      const now = new Date();
      var cmonth = now.getMonth();
      var cyear = now.getFullYear();
     
      if(cmonth >=1 && cmonth <=3) {
        this.startDate = this.datePipe.transform(new Date(now.getFullYear(), 0, 1), 'yyyy-MM-dd');
        this.endDate = this.datePipe.transform(new Date(now.getFullYear(), 3, 0), 'yyyy-MM-dd');
      }
      else if(cmonth >=4 && cmonth <=6) {
        this.startDate = this.datePipe.transform(new Date(now.getFullYear(), 3, 1), 'yyyy-MM-dd');
        this.endDate = this.datePipe.transform(new Date(now.getFullYear(), 6, 0), 'yyyy-MM-dd'); }
      else if(cmonth >=7 && cmonth <=9) {
        this.startDate = this.datePipe.transform(new Date(now.getFullYear(), 6, 1), 'yyyy-MM-dd');
        this.endDate = this.datePipe.transform(new Date(now.getFullYear(), 9, 0), 'yyyy-MM-dd'); }
      else if(cmonth >=10 && cmonth <=12) {1
        this.startDate = this.datePipe.transform(new Date(now.getFullYear(), 9, 1), 'yyyy-MM-dd');
        this.endDate = this.datePipe.transform(new Date(now.getFullYear(), 12, 0), 'yyyy-MM-dd');  }
    this.loadDentist('all');
    
    }
    else if (duration == 'lq') {
      const now = new Date();
      var cmonth = now.getMonth();
      var cyear = now.getFullYear();
     
      if(cmonth >=1 && cmonth <=3) {
        this.startDate = this.datePipe.transform(new Date(now.getFullYear() -1, 9, 1), 'yyyy-MM-dd');
        this.endDate = this.datePipe.transform(new Date(now.getFullYear()-1, 12, 0), 'yyyy-MM-dd');
      }
      else if(cmonth >=4 && cmonth <=6) {
        this.startDate = this.datePipe.transform(new Date(now.getFullYear(), 0, 1), 'yyyy-MM-dd');
        this.endDate = this.datePipe.transform(new Date(now.getFullYear(), 3, 0), 'yyyy-MM-dd'); }
      else if(cmonth >=7 && cmonth <=9) {
        this.startDate = this.datePipe.transform(new Date(now.getFullYear(), 3, 1), 'yyyy-MM-dd');
        this.endDate = this.datePipe.transform(new Date(now.getFullYear(), 6, 0), 'yyyy-MM-dd'); }
      else if(cmonth >=10 && cmonth <=12) {
        this.startDate = this.datePipe.transform(new Date(now.getFullYear(), 6, 1), 'yyyy-MM-dd');
        this.endDate = this.datePipe.transform(new Date(now.getFullYear(), 9, 0), 'yyyy-MM-dd');  }
    this.loadDentist('all');
   
    }
    else if (duration == 'cytd') {
     var date = new Date();
      this.startDate = this.datePipe.transform(new Date(date.getFullYear(), 0, 1), 'yyyy-MM-dd');
      this.endDate = this.datePipe.transform(new Date(), 'yyyy-MM-dd');
      this.loadDentist('all');
    }
     else if (duration == 'fytd') {
     var date = new Date();
      this.startDate = this.datePipe.transform(new Date(date.getFullYear(), 3, 1), 'yyyy-MM-dd');
      this.endDate = this.datePipe.transform(new Date(), 'yyyy-MM-dd');

      this.loadDentist('all');
    }
     else if (duration == 'custom') {
     $('.customRange').css('display','block');
    }
    $('.filter').removeClass('active');
    $('.filter_'+duration).addClass("active");
      $('.filter_custom').val(this.startDate+ " - "+this.endDate);

  }

  // Get Dentist
    getDentists() {
      this.dentistService.getDentists(this.clinic_id).subscribe((res) => {
           if(res.message == 'success'){
              this.dentists= res.data;
              this.dentistCount= res.data.length;

           }
        }, error => {
          this.warningMessage = "Please Provide Valid Inputs!";
        }    
        );
  }
  changeDentistPredictor(val){
    if(val =='1') {
       this.gaugeValuePredicted= this.gaugeValuePredicted1*100;
           this.predictedDentistTotal = this.gaugeValuePredicted1;

     }
    else if(val =='2'){
       this.gaugeValuePredicted= this.gaugeValuePredicted2*100;
           this.predictedDentistTotal = this.gaugeValuePredicted2;

     }
    else if(val =='3') {
       this.gaugeValuePredicted= this.gaugeValuePredicted3*100;  
           this.predictedDentistTotal = this.gaugeValuePredicted3;

     }
  } 
  ytd_load(val) {
    alert(this.datePipe.transform(val, 'yyyy-MM-dd'));
  }
choosedDate(val) {
    val = (val.chosenLabel);
    var val= val.toString().split(' - ');
      this.startDate = this.datePipe.transform(val[0], 'yyyy-MM-dd');
      this.endDate = this.datePipe.transform(val[1], 'yyyy-MM-dd');
      this.loadDentist('all');
      
      $('.filter_custom').val(this.startDate+ " - "+this.endDate);
     $('.customRange').css('display','none');
}
toggleFilter(val) {
    $('.filter').removeClass('active');
  
    if(val == 'current') {
      var date = new Date();
       this.startDate = this.datePipe.transform(new Date(date.getFullYear(), 0, 1), 'yyyy-MM-dd');
      this.endDate =this.datePipe.transform(new Date(date.getFullYear(), 12, 0), 'yyyy-MM-dd');
      this.loadDentist('all'); 
  }
  else if(val == 'historic') {
      var date = new Date();
       this.startDate = '';
      this.endDate ='';
      this.loadDentist('all'); 
  }
  else if(val == 'off') {
       this.filterDate('m');
  }
}
flipcard(div){
 if( $('.'+div).hasClass('active'))
  $('.'+div).removeClass('active');
else
  $('.'+div).addClass('active');
}
  initiate_dentist() {
    var val = $('.internal_dentist').val();
    this.loadDentist(val);
  }
}
