import { Routes } from '@angular/router';

import { ClinicianAnalysisComponent } from './cliniciananalysis/cliniciananalysis.component';
import { ClinicianProceeduresComponent } from './clinicianproceedures/clinicianproceedures.component';
import { FinancesComponent } from './finances/finances.component';

export const DashboardsRoutes: Routes = [
  {
    path: '',
    children: [
      {
        path: 'cliniciananalysis/:id',
        component: ClinicianAnalysisComponent
      },
      {
        path: 'clinicianproceedures/:id',
        component: ClinicianProceeduresComponent
      },
      {
        path: 'finances/:id',
        component: FinancesComponent
      }
    ]
  }
];
