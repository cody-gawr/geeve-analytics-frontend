import { Component, AfterViewInit, SecurityContext, ViewEncapsulation, OnInit , ViewChild,ElementRef } from '@angular/core';
import { ClinicianProceeduresService } from './clinicianproceedures.service';
import { DentistService } from '../../dentist/dentist.service';

import * as frLocale from 'date-fns/locale/fr';
import { DatePipe } from '@angular/common';
import {
  FormControl,
  FormGroupDirective,
  NgForm,
  Validators
} from '@angular/forms';
import { ActivatedRoute } from "@angular/router";
import 'chartjs-plugin-style';
export interface Dentist {
  providerId: string;
  name: string;
}

@Component({
  templateUrl: './clinicianproceedures.component.html'
})
export class ClinicianProceeduresComponent implements AfterViewInit {
    @ViewChild("myCanvas") canvas: ElementRef;
  lineChartColors;
  doughnutChartColors;
  subtitle: string;
   public clinic_id:any ={};
   public dentistCount:any ={};
  
  constructor(private clinicianproceeduresService: ClinicianProceeduresService, private dentistService: DentistService, private datePipe: DatePipe, private route: ActivatedRoute){
  }
  private warningMessage: string;

  ngAfterViewInit() {
 this.route.params.subscribe(params => {
    this.clinic_id = this.route.snapshot.paramMap.get("id");
        this.filterDate('m');
        this.getDentists(); 
        this.loadDentist('all');
     });
  let gradient = this.canvas.nativeElement.getContext('2d').createLinearGradient(0, 0, 0, 400);
gradient.addColorStop(0, 'rgba(104, 255, 249, 1)');
gradient.addColorStop(1, 'rgba(28, 164, 159, 1)');
let gradient1 = this.canvas.nativeElement.getContext('2d').createLinearGradient(0, 0, 0, 100);
gradient1.addColorStop(1, '#4FC1D1');
gradient1.addColorStop(0,  '#BFE8EE');
let gradient2 = this.canvas.nativeElement.getContext('2d').createLinearGradient(0, 0, 0, 100);
gradient2.addColorStop(1, '#79BCB8');
gradient2.addColorStop(0,  '#A9D4D1');
let gradient3 = this.canvas.nativeElement.getContext('2d').createLinearGradient(0, 0, 0, 100);
gradient3.addColorStop(1, '#3AA7A3');
gradient3.addColorStop(0,  '#86C0A9');
let gradient4 = this.canvas.nativeElement.getContext('2d').createLinearGradient(0, 0, 0, 100);
gradient4.addColorStop(1, '#1D6A69');
gradient4.addColorStop(0,  '#B2DEDD');
let gradient5 = this.canvas.nativeElement.getContext('2d').createLinearGradient(0, 0, 0, 100);
gradient5.addColorStop(1, '#A9D4D1');
gradient5.addColorStop(0,  '#8BCECD');
this.doughnutChartColors = [{backgroundColor: [gradient5,gradient4,gradient3,gradient2,gradient1,gradient]}];
this.lineChartColors = [
  {
    backgroundColor: gradient,
    hoverBorderWidth: 2,
    hoverBorderColor: '#1CA49F'
  },
   {
    backgroundColor: gradient1,
    hoverBorderWidth: 2,
    hoverBorderColor: '#1CA49F'
  },
  {
    backgroundColor: gradient2,
    hoverBorderWidth: 2,
    hoverBorderColor: '#1CA49F'
  },
   {
    backgroundColor: gradient3,
    hoverBorderWidth: 2,
    hoverBorderColor: '#1CA49F'
  },
  {
    backgroundColor: gradient4,
    hoverBorderWidth: 2,
    hoverBorderColor: '#1CA49F'
  },
   {
    backgroundColor: gradient5,
    hoverBorderWidth: 2,
    hoverBorderColor: '#1CA49F'
  }
];
  }

  public date =new Date();

  dentists: Dentist[] = [
   { providerId: 'all', name: 'All Dentists' },
  ];
    public stackedChartOptions: any = {
    scaleShowVerticalLines: false,
           responsive: true,
    maintainAspectRatio: false,
    barThickness: 10,
      animation: {
        duration: 1500,
        easing: 'easeOutSine'
      },
    scales: {
          xAxes: [{ 
            stacked: true, 
            ticks: {
                autoSkip: false
            }
            }],
          yAxes: [{ 
            stacked: true, 
            ticks: {
              
            }, 
            }],
        }
  };
    public pieChartOptions: any = {
    responsive: true,
    maintainAspectRatio: false,
    legend: {
            display: false
         }
  };
   public barChartOptions: any = {
    scaleShowVerticalLines: false,
           responsive: true,
    maintainAspectRatio: false,
      animation: {
        duration: 1500,
        easing: 'easeOutSine'
      },
    barThickness: 10,
        scales: {
          xAxes: [{ 
            ticks: {
                  autoSkip: false
              }
            }],
          yAxes: [{  
            ticks: {
             
            }, 
            }],
        },
         legend: {
        position: 'top',
        onClick: function(e, legendItem) {
          var index = legendItem.datasetIndex;
          var ci = this.chart; 
          if(index ==0)
          {
                (<HTMLElement>document.querySelector('.predicted1')).style.display = 'flex';
                
                (<HTMLElement>document.querySelector('.predicted2')).style.display = 'none';
                (<HTMLElement>document.querySelector('.predicted3')).style.display = 'none';

                ci.getDatasetMeta(1).hidden = true;
                ci.getDatasetMeta(2).hidden = true;
                ci.getDatasetMeta(index).hidden = false;
          }
          else if(index== 1) {
            (<HTMLElement>document.querySelector('.predicted1')).style.display = 'none';
                (<HTMLElement>document.querySelector('.predicted2')).style.display = 'flex';

                (<HTMLElement>document.querySelector('.predicted3')).style.display = 'none';
                ci.getDatasetMeta(0).hidden = true;
                ci.getDatasetMeta(2).hidden = true;
                ci.getDatasetMeta(index).hidden = false;
          } 
          else if(index== 2) {
            (<HTMLElement>document.querySelector('.predicted1')).style.display = 'none';
                (<HTMLElement>document.querySelector('.predicted2')).style.display = 'none';
                (<HTMLElement>document.querySelector('.predicted3')).style.display = 'flex';

                ci.getDatasetMeta(0).hidden = true;
                ci.getDatasetMeta(1).hidden = true;
                ci.getDatasetMeta(index).hidden = false;
          }
          ci.update();
        },
      }     
          };


  public proceedureChartOptions: any = {
    scaleShowVerticalLines: false,
           responsive: true,
    maintainAspectRatio: false,
    barThickness: 10,
      animation: {
        duration: 1500,
        easing: 'easeOutSine'
      },
        scales: {
          xAxes: [{ 
            ticks: {
                  autoSkip: false
              }
            }],
          yAxes: [{  
            ticks: {
             
            }, 
            }],
        },
         legend: {
        position: 'top',
      },
      tooltips: {
  callbacks: {
    label: function(tooltipItems, data) { 
      return data.datasets[tooltipItems.datasetIndex].label+": $"+tooltipItems.yLabel;
    }
  }
},        
  };

  public selectedDentist: string;
  public predicted1: boolean = true;
  public predicted2: boolean = false;
  public predicted3: boolean = false;
  public showInternal: boolean = true;
  public showExternal: boolean = false;
  public showCombined: boolean = false;
  public stackedChartColors: Array<any> = [
    { backgroundColor: '#76F2E5' },
    { backgroundColor: '#6BE6EF' },
    { backgroundColor: '#68D8D6' },
    { backgroundColor: '#3DCCC7' },
    { backgroundColor: '#68FFF9' },
    { backgroundColor: '#07BEB8' }
  ];
  public stackedChartType = 'bar';
  public stackedChartLegend = true;

  //labels
  public stackedChartLabels: string[] = [];  
  public stackedChartLabels1: string[] = [];

  public predictedChartLabels: string[] = [];
  public predictedChartLabels1: string[] = [];

  public proceedureChartLabels: string[] = [];
  public proceedureChartLabels1: string[] = [];
  public proceedureDentistChartLabels: string[] = [];
  //data
  public stackedChartData: any[] = [
    {data: [], label: 'Crowns',  shadowOffsetX: 3,
            shadowOffsetY: 3,
            shadowBlur: 5,
            shadowColor: 'rgba(0, 0, 0, 0.5)',
            pointBevelWidth: 2,
            pointBevelHighlightColor: 'rgba(255, 255, 255, 0.75)',
            pointBevelShadowColor: 'rgba(0, 0, 0, 0.5)',
            pointShadowOffsetX: 3,
            pointShadowOffsetY: 3,
            pointShadowBlur: 10,
            pointShadowColor: 'rgba(0, 0, 0, 0.5)',
            backgroundOverlayMode: 'multiply'},
    {data: [], label: 'Splints ' ,  shadowOffsetX: 3,
            shadowOffsetY: 3,
            shadowBlur: 5,
            shadowColor: 'rgba(0, 0, 0, 0.5)',
            pointBevelWidth: 2,
            pointBevelHighlightColor: 'rgba(255, 255, 255, 0.75)',
            pointBevelShadowColor: 'rgba(0, 0, 0, 0.5)',
            pointShadowOffsetX: 3,
            pointShadowOffsetY: 3,
            pointShadowBlur: 10,
            pointShadowColor: 'rgba(0, 0, 0, 0.5)',
            backgroundOverlayMode: 'multiply'},
    {data: [], label: 'Root Canals' ,  shadowOffsetX: 3,
            shadowOffsetY: 3,
            shadowBlur: 5,
            shadowColor: 'rgba(0, 0, 0, 0.5)',
            pointBevelWidth: 2,
            pointBevelHighlightColor: 'rgba(255, 255, 255, 0.75)',
            pointBevelShadowColor: 'rgba(0, 0, 0, 0.5)',
            pointShadowOffsetX: 3,
            pointShadowOffsetY: 3,
            pointShadowBlur: 10,
            pointShadowColor: 'rgba(0, 0, 0, 0.5)',
            backgroundOverlayMode: 'multiply'},
    {data: [], label: 'Perio Charts' ,  shadowOffsetX: 3,
            shadowOffsetY: 3,
            shadowBlur: 5,
            shadowColor: 'rgba(0, 0, 0, 0.5)',
            pointBevelWidth: 2,
            pointBevelHighlightColor: 'rgba(255, 255, 255, 0.75)',
            pointBevelShadowColor: 'rgba(0, 0, 0, 0.5)',
            pointShadowOffsetX: 3,
            pointShadowOffsetY: 3,
            pointShadowBlur: 10,
            pointShadowColor: 'rgba(0, 0, 0, 0.5)',
            backgroundOverlayMode: 'multiply'},
    {data: [], label: 'Surgical Extractions' ,  shadowOffsetX: 3,
            shadowOffsetY: 3,
            shadowBlur: 5,
            shadowColor: 'rgba(0, 0, 0, 0.5)',
            pointBevelWidth: 2,
            pointBevelHighlightColor: 'rgba(255, 255, 255, 0.75)',
            pointBevelShadowColor: 'rgba(0, 0, 0, 0.5)',
            pointShadowOffsetX: 3,
            pointShadowOffsetY: 3,
            pointShadowBlur: 10,
            pointShadowColor: 'rgba(0, 0, 0, 0.5)',
            backgroundOverlayMode: 'multiply'}  ];

  public stackedChartData1: any[] = [];
  public stackedChartData2: any[] = [];
  public stackedChartData3: any[] = [];
  public stackedChartData4: any[] = [];
  public stackedChartData5: any[] = [];

  public predictedChartData: any[] = [
    {data: [], label: 'Crown to Large Filling',  shadowOffsetX: 3,
            shadowOffsetY: 3,
            shadowBlur: 5,
            shadowColor: 'rgba(0, 0, 0, 0.5)',
            pointBevelWidth: 2,
            pointBevelHighlightColor: 'rgba(255, 255, 255, 0.75)',
            pointBevelShadowColor: 'rgba(0, 0, 0, 0.5)',
            pointShadowOffsetX: 3,
            pointShadowOffsetY: 3,
            pointShadowBlur: 10,
            pointShadowColor: 'rgba(0, 0, 0, 0.5)',
            backgroundOverlayMode: 'multiply'},
    {data: [], label: 'Extraction to RCT',hidden: true,  shadowOffsetX: 3,
            shadowOffsetY: 3,
            shadowBlur: 5,
            shadowColor: 'rgba(0, 0, 0, 0.5)',
            pointBevelWidth: 2,
            pointBevelHighlightColor: 'rgba(255, 255, 255, 0.75)',
            pointBevelShadowColor: 'rgba(0, 0, 0, 0.5)',
            pointShadowOffsetX: 3,
            pointShadowOffsetY: 3,
            pointShadowBlur: 10,
            pointShadowColor: 'rgba(0, 0, 0, 0.5)',
            backgroundOverlayMode: 'multiply'},
    {data: [], label: 'RCT Conversion',hidden: true,  shadowOffsetX: 3,
            shadowOffsetY: 3,
            shadowBlur: 5,
            shadowColor: 'rgba(0, 0, 0, 0.5)',
            pointBevelWidth: 2,
            pointBevelHighlightColor: 'rgba(255, 255, 255, 0.75)',
            pointBevelShadowColor: 'rgba(0, 0, 0, 0.5)',
            pointShadowOffsetX: 3,
            pointShadowOffsetY: 3,
            pointShadowBlur: 10,
            pointShadowColor: 'rgba(0, 0, 0, 0.5)',
            backgroundOverlayMode: 'multiply'},

    ];

  public predictedChartData1: any[] = [];  
  public predictedChartData2: any[] = [];  
  public predictedChartData3: any[] = [];  

  public proceedureChartType = 'horizontalBar';

  public proceedureChartData: any[] = [
    {data: [], label: 'Total Revenue of Clinician Per Procedure',  shadowOffsetX: 3,
            shadowOffsetY: 3,
            shadowBlur: 5,
            shadowColor: 'rgba(0, 0, 0, 0.5)',
            pointBevelWidth: 2,
            pointBevelHighlightColor: 'rgba(255, 255, 255, 0.75)',
            pointBevelShadowColor: 'rgba(0, 0, 0, 0.5)',
            pointShadowOffsetX: 3,
            pointShadowOffsetY: 3,
            pointShadowBlur: 10,
            pointShadowColor: 'rgba(0, 0, 0, 0.5)',
            backgroundOverlayMode: 'multiply'}
    ];
  public proceedureDentistChartData: any[] = [
    {data: [], label: 'Total Revenue of Clinician Per Procedure',  shadowOffsetX: 3,
            shadowOffsetY: 3,
            shadowBlur: 5,
            shadowColor: 'rgba(0, 0, 0, 0.5)',
            pointBevelWidth: 2,
            pointBevelHighlightColor: 'rgba(255, 255, 255, 0.75)',
            pointBevelShadowColor: 'rgba(0, 0, 0, 0.5)',
            pointShadowOffsetX: 3,
            pointShadowOffsetY: 3,
            pointShadowBlur: 10,
            pointShadowColor: 'rgba(0, 0, 0, 0.5)',
            backgroundOverlayMode: 'multiply'}
    ];
  public proceedureChartData1: any[] = []; 
 

  //Total  
  public predictedTotal1 = 0;
  public predictedTotal2 = 0;
  public predictedTotal3 = 0;

  public predictedTotalAverage1 = 0;
  public predictedTotalAverage2 = 0;
  public predictedTotalAverage3 = 0;

  public pieChartInternalTotal = 0;
  public pieChartExternalTotal = 0;
  public pieChartCombinedTotal = 0;

  // Pie
  public pieChartLabels: string[] = [
  ];
  public pieChartData1: number[] = [];
  public pieChartData2: number[] = [];
  public pieChartData3: number[] = [];
  public pieChartType = 'pie';
  public pieChartDatares1: number[] = [];
  public pieChartDatares2: number[] = [];
  public pieChartDatares3: number[] = [];

  public pieChartLabelsres: string[] = [
  ];

  public itemPredictedChartData: any[] = [
    {data: [10,1,5], label: 'Items Predictor Analysis ',  shadowOffsetX: 3,
            shadowOffsetY: 2,
            shadowBlur: 3,
            shadowColor: 'rgba(0, 0, 0, 0.3)',
            pointBevelWidth: 2,
            pointBevelHighlightColor: 'rgba(255, 255, 255, 0.75)',
            pointBevelShadowColor: 'rgba(0, 0, 0, 0.3)',
            pointShadowOffsetX: 3,
            pointShadowOffsetY: 3,
            pointShadowBlur: 10,
            pointShadowColor: 'rgba(0, 0, 0, 0.3)',
            backgroundOverlayMode: 'multiply'}

    ];
        
  public itemPredictedChartData1: any[] = [];  

  public itemPredictedChartLabels: string[] = [];

  // events
  public chartClicked(e: any): void {
    console.log(e);
  }

  public chartHovered(e: any): void {
    console.log(e);
  }
  public  gaugeType = "arch";
  public  gaugeValue = '';
  public  gaugeLabel = "";
  public  gaugeThick = "20";
  public  foregroundColor= "rgba(0, 150, 136,0.5)";
  public  cap= "round";
  public  size = "250"
  public  gaugeValuePredicted = 0;
  public  gaugeValuePredicted1 = 0;

  public  gaugeValuePredicted2 = 0;

  public  gaugeValuePredicted3 = 0;
  public  gaugeLabelPredicted = "";
  public predictedDentistTotal = 0;
  public gaugePrependText ='$';
  public startDate ='';
  public endDate = '';
 private loadDentist(newValue) {
  if(newValue == 'all') {
    $(".trend_toggle").hide();
    this.buildChartPredictor();
    this.buildChart();
    this.buildChartProceedure();
    this.buildChartReferral();
    (<HTMLElement>document.querySelector('.itemsPredictorSingle')).style.display = 'none';
    (<HTMLElement>document.querySelector('.itemsPredictor')).style.display = 'block';

    (<HTMLElement>document.querySelector('.ratioPredictorSingle')).style.display = 'none';
    (<HTMLElement>document.querySelector('.ratioPredictor')).style.display = 'block';    

        (<HTMLElement>document.querySelector('.revenueProceedureSingle')).style.display = 'none';
    (<HTMLElement>document.querySelector('.revenueProceedure')).style.display = 'block';
/*
    (<HTMLElement>document.querySelector('.treatmentPlanSingle')).style.display = 'none';
    (<HTMLElement>document.querySelector('.treatmentPlan')).style.display = 'block';

    (<HTMLElement>document.querySelector('.noPatientsSingle')).style.display = 'none';
    (<HTMLElement>document.querySelector('.noPatients')).style.display = 'block';*/
  }
  else {
    $(".trend_toggle").show();
    this.selectedDentist = newValue;
    this.buildChartDentist();
    (<HTMLElement>document.querySelector('.itemsPredictorSingle')).style.display = 'block';
    (<HTMLElement>document.querySelector('.itemsPredictor')).style.display = 'none';

    this.buildChartPredictorDentist();
    (<HTMLElement>document.querySelector('.ratioPredictorSingle')).style.display = 'block';
    (<HTMLElement>document.querySelector('.ratioPredictor')).style.display = 'none';

    this.buildChartProceedureDentist();
    (<HTMLElement>document.querySelector('.revenueProceedureSingle')).style.display = 'block';
    (<HTMLElement>document.querySelector('.revenueProceedure')).style.display = 'none';
    this.buildChartReferralDentist();
/*    this.buildChartTreatmentDentist();
    (<HTMLElement>document.querySelector('.treatmentPlanSingle')).style.display = 'block';
    (<HTMLElement>document.querySelector('.treatmentPlan')).style.display = 'none';

    this.buildChartNopatientsDentist();
    (<HTMLElement>document.querySelector('.noPatientsSingle')).style.display = 'block';
    (<HTMLElement>document.querySelector('.noPatients')).style.display = 'none';*/
  }

  }

  //Items Predictor Analysis 
  private buildChart() {

    var user_id;
    var clinic_id;
       this.stackedChartData = [
    {data: [], label: 'Crowns',  shadowOffsetX: 3,
            shadowOffsetY: 3,
            shadowBlur: 5,
            shadowColor: 'rgba(0, 0, 0, 0.5)',
            pointBevelWidth: 2,
            pointBevelHighlightColor: 'rgba(255, 255, 255, 0.75)',
            pointBevelShadowColor: 'rgba(0, 0, 0, 0.5)',
            pointShadowOffsetX: 3,
            pointShadowOffsetY: 3,
            pointShadowBlur: 10,
            pointShadowColor: 'rgba(0, 0, 0, 0.5)',
            backgroundOverlayMode: 'multiply'},
    {data: [], label: 'Splints ' ,  shadowOffsetX: 3,
            shadowOffsetY: 3,
            shadowBlur: 5,
            shadowColor: 'rgba(0, 0, 0, 0.5)',
            pointBevelWidth: 2,
            pointBevelHighlightColor: 'rgba(255, 255, 255, 0.75)',
            pointBevelShadowColor: 'rgba(0, 0, 0, 0.5)',
            pointShadowOffsetX: 3,
            pointShadowOffsetY: 3,
            pointShadowBlur: 10,
            pointShadowColor: 'rgba(0, 0, 0, 0.5)',
            backgroundOverlayMode: 'multiply'},
    {data: [], label: 'Root Canals' ,  shadowOffsetX: 3,
            shadowOffsetY: 3,
            shadowBlur: 5,
            shadowColor: 'rgba(0, 0, 0, 0.5)',
            pointBevelWidth: 2,
            pointBevelHighlightColor: 'rgba(255, 255, 255, 0.75)',
            pointBevelShadowColor: 'rgba(0, 0, 0, 0.5)',
            pointShadowOffsetX: 3,
            pointShadowOffsetY: 3,
            pointShadowBlur: 10,
            pointShadowColor: 'rgba(0, 0, 0, 0.5)',
            backgroundOverlayMode: 'multiply'},
    {data: [], label: 'Perio Charts' ,  shadowOffsetX: 3,
            shadowOffsetY: 3,
            shadowBlur: 5,
            shadowColor: 'rgba(0, 0, 0, 0.5)',
            pointBevelWidth: 2,
            pointBevelHighlightColor: 'rgba(255, 255, 255, 0.75)',
            pointBevelShadowColor: 'rgba(0, 0, 0, 0.5)',
            pointShadowOffsetX: 3,
            pointShadowOffsetY: 3,
            pointShadowBlur: 10,
            pointShadowColor: 'rgba(0, 0, 0, 0.5)',
            backgroundOverlayMode: 'multiply'},
    {data: [], label: 'Surgical Extractions' ,  shadowOffsetX: 3,
            shadowOffsetY: 3,
            shadowBlur: 5,
            shadowColor: 'rgba(0, 0, 0, 0.5)',
            pointBevelWidth: 2,
            pointBevelHighlightColor: 'rgba(255, 255, 255, 0.75)',
            pointBevelShadowColor: 'rgba(0, 0, 0, 0.5)',
            pointShadowOffsetX: 3,
            pointShadowOffsetY: 3,
            pointShadowBlur: 10,
            pointShadowColor: 'rgba(0, 0, 0, 0.5)',
            backgroundOverlayMode: 'multiply'}  ];

  this.stackedChartData1 = [];
  this.stackedChartData2 = [];
  this.stackedChartData3 = [];
  this.stackedChartData4 = [];
  this.stackedChartData5 = [];
  this.stackedChartLabels1 =[];
  this.stackedChartLabels =[];
  this.clinicianproceeduresService.ItemsPredictorAnalysis(this.clinic_id,this.startDate,this.endDate).subscribe((data) => {
       if(data.message == 'success'){
        if(data.data.length <=0) {

        }else {
        data.data.forEach(res => {
           this.stackedChartData1.push(res.crowns);
           this.stackedChartData2.push(res.splints);
           this.stackedChartData3.push(res.root_canals);
           this.stackedChartData4.push(res.perio);
           this.stackedChartData5.push(res.surgical_extractions);
           this.stackedChartLabels1.push(res.provider);
       //    this.productionTotal = this.productionTotal + parseInt(res.total);
         });
      
       this.stackedChartData[0]['data'] = this.stackedChartData1;
       this.stackedChartData[1]['data'] = this.stackedChartData2;
       this.stackedChartData[2]['data'] = this.stackedChartData3;
       this.stackedChartData[3]['data'] = this.stackedChartData4;
       this.stackedChartData[4]['data'] = this.stackedChartData5;

       this.stackedChartLabels = this.stackedChartLabels1;
       //this.productionTotalAverage = this.productionTotal/this.barChartData1.length;
     }
       }
    }, error => {
      this.warningMessage = "Please Provide Valid Inputs!";
 
    }
    );
  }

  //Items Predictor Analysis Single
  private buildChartDentist() {
    var user_id;
    var clinic_id;
  this.clinicianproceeduresService.ItemsPredictorAnalysisDentist(this.selectedDentist, this.clinic_id,this.startDate,this.endDate).subscribe((data) => {
       if(data.message == 'success'){
          this.itemPredictedChartData1 = [];
          this.itemPredictedChartData1.push(data.data[0].crowns);
          this.itemPredictedChartData1.push(data.data[0].splints);
          this.itemPredictedChartData1.push(data.data[0].root_canals);
          this.itemPredictedChartData1.push(data.data[0].perio);
          this.itemPredictedChartData1.push(data.data[0].surgical_extractions);

       this.itemPredictedChartData[0]['data'] = this.itemPredictedChartData1;
       this.itemPredictedChartData[0]['label'] = data.data[0].provider;
       this.itemPredictedChartLabels= ['Crowns','Splints','Root Canals','Perio','Surgical Extractions'];

       }
    }, error => {
      this.warningMessage = "Please Provide Valid Inputs!";
 
    }
    );
  }

//Predictor Ratio :
  private buildChartPredictor() {
    this.predictedChartData1 =[];
           this.predictedChartData2 =[];
           this.predictedChartData3 =[];
           this.predictedChartLabels1=[];
           this.predictedChartData[0]['data'] = [];
       this.predictedChartData[1]['data'] = [];
       this.predictedChartData[2]['data'] = [];
       this.predictedTotal1 = 0;
           this.predictedTotal2 = 0;
           this.predictedTotal3 =0;
       var user_id;
    var clinic_id;
  this.clinicianproceeduresService.PredictorRatio(this.clinic_id,this.startDate,this.endDate).subscribe((data) => {
       if(data.message == 'success'){
        data.data.forEach(res => {
           this.predictedChartData1.push(res.ratio1);
           this.predictedChartData2.push(res.ratio2);
           this.predictedChartData3.push(res.ratio3);
           this.predictedChartLabels1.push(res.provider);
           this.predictedTotal1 = this.predictedTotal1 + parseInt(res.ratio1);
           this.predictedTotal2 = this.predictedTotal2 + parseInt(res.ratio2);
           this.predictedTotal3 = this.predictedTotal3 + parseInt(res.ratio3);
 });
       this.predictedChartData[0]['data'] = this.predictedChartData1;
       this.predictedChartData[1]['data'] = this.predictedChartData2;
       this.predictedChartData[2]['data'] = this.predictedChartData3;
        console.log(this.predictedTotal1+"/"+this.predictedChartData1.length);

       this.predictedTotalAverage1 = this.predictedTotal1/this.predictedChartData1.length;
       this.predictedTotalAverage2 = this.predictedTotal2/this.predictedChartData2.length;
       this.predictedTotalAverage3 = this.predictedTotal3/this.predictedChartData3.length;

       this.predictedChartLabels = this.predictedChartLabels1;
       }
       console.log(this.predictedTotalAverage1);
    }, error => {
      this.warningMessage = "Please Provide Valid Inputs!";
 
    }
    );
  }
  //Predictor Ratio :
  private buildChartPredictorDentist() {
       var user_id;
    var clinic_id;
  this.clinicianproceeduresService.PredictorRatioDentist(this.selectedDentist, this.clinic_id,this.startDate,this.endDate).subscribe((data) => {
       if(data.message == 'success'){
           this.gaugeValuePredicted1 = data.data[0].ratio1;
           this.gaugeValuePredicted2 = data.data[0].ratio2;
           this.gaugeValuePredicted3 = data.data[0].ratio3;
           this.gaugeLabelPredicted = data.data[0].provider;
           this.predictedDentistTotal = data.data[0].ratio1;
           this.gaugeValuePredicted= this.gaugeValuePredicted1*100;
       }
    }, error => {
      this.warningMessage = "Please Provide Valid Inputs!";
 
    }
    );
  }

//Total Revenue of Clinician Per Procedure
  private buildChartProceedure() {
        var user_id;
    var clinic_id;
     this.proceedureChartData1 =[];
           this.proceedureChartLabels1 = [];
  this.clinicianproceeduresService.ClinicianProceedure( this.clinic_id,this.startDate,this.endDate).subscribe((data) => {
       if(data.message == 'success'){
        data.data.forEach(res => {
           this.proceedureChartData1.push(res.total);
           this.proceedureChartLabels1.push(res.treat_item);
       //    this.productionTotal = this.productionTotal + parseInt(res.total);
 });
       this.proceedureChartData[0]['data'] = this.proceedureChartData1;
       this.proceedureChartLabels = this.proceedureChartLabels1;
       }
    }, error => {
      this.warningMessage = "Please Provide Valid Inputs!";
 
    }
    );
  }


//Total Revenue of Clinician Per Procedure
  private buildChartProceedureDentist() {
        var user_id;
    var clinic_id;
    this.proceedureChartData1 = [];
           this.proceedureChartLabels1 = [];
  this.clinicianproceeduresService.ClinicianProceedureDentist(this.selectedDentist, this.clinic_id,this.startDate,this.endDate).subscribe((data) => {
       if(data.message == 'success'){
        data.data.forEach(res => {
           this.proceedureChartData1.push(res.total);
           this.proceedureChartLabels1.push(res.treat_item);
       //    this.productionTotal = this.productionTotal + parseInt(res.total);
 });
       this.proceedureDentistChartData[0]['data'] = this.proceedureChartData1;
       this.proceedureDentistChartLabels = this.proceedureChartLabels1;
       }
    }, error => {
      this.warningMessage = "Please Provide Valid Inputs!";
 
    }
    );
  }

  //Referral to Other Clinicians Internal / External
  private buildChartReferral() {
        var user_id;
    var clinic_id;
    this.pieChartInternalTotal = 0;
           this.pieChartExternalTotal = 0;
           this.pieChartCombinedTotal =0;
  this.clinicianproceeduresService.ClinicianReferral(this.clinic_id,this.startDate,this.endDate).subscribe((data) => {
       if(data.message == 'success'){
                  this.pieChartDatares1 = [];
           this.pieChartDatares2 = [];
           this.pieChartDatares3 = [];
           this.pieChartLabelsres = [];
        data.data.forEach(res => {
           this.pieChartDatares1.push(res.i_count);
           this.pieChartDatares2.push(res.e_count);
           this.pieChartDatares3.push(res.total);
           this.pieChartLabelsres.push(res.label);
           this.pieChartInternalTotal = this.pieChartInternalTotal + parseInt(res.i_count);
           this.pieChartExternalTotal = this.pieChartExternalTotal + parseInt(res.e_count);
           this.pieChartCombinedTotal = this.pieChartCombinedTotal + parseInt(res.total);
 });

       this.pieChartData1 = this.pieChartDatares1;
       this.pieChartData2 = this.pieChartDatares2;
       this.pieChartData3 = this.pieChartDatares3;
       this.pieChartLabels = this.pieChartLabelsres;
       }
    }, error => {
      this.warningMessage = "Please Provide Valid Inputs!";
 
    }
    );
  }

  //Referral to Other Clinicians Internal / External
  private buildChartReferralDentist() {
        var user_id;
    var clinic_id;
     this.pieChartInternalTotal = 0;
           this.pieChartExternalTotal = 0;
           this.pieChartCombinedTotal =0;
  this.clinicianproceeduresService.ClinicianReferralDentist(this.selectedDentist, this.clinic_id,this.startDate,this.endDate).subscribe((data) => {
       if(data.message == 'success'){
          this.pieChartDatares1 = [];
           this.pieChartDatares2 = [];
           this.pieChartDatares3 = [];
           this.pieChartLabelsres = [];
        data.data.forEach(res => {
           this.pieChartDatares1.push(res.i_count);
           this.pieChartDatares2.push(res.e_count);
           this.pieChartDatares3.push(res.total);
           this.pieChartLabelsres.push(res.label);
           this.pieChartInternalTotal = this.pieChartInternalTotal + parseInt(res.i_count);
           this.pieChartExternalTotal = this.pieChartExternalTotal + parseInt(res.e_count);
           this.pieChartCombinedTotal = this.pieChartCombinedTotal + parseInt(res.total);
 });

       this.pieChartData1 = this.pieChartDatares1;
       this.pieChartData2 = this.pieChartDatares2;
       this.pieChartData3 = this.pieChartDatares3;

       this.pieChartLabels = this.pieChartLabelsres;
       }
    }, error => {
      this.warningMessage = "Please Provide Valid Inputs!";
 
    }
    );
  }

   changePieReferral(chart){
    this.showInternal =false;
    this.showExternal = false;
    this.showCombined = false;
    if(chart == 'Internal') 
      this.showInternal = true;
    else if(chart == 'External')
      this. showExternal =true;
    else if(chart == 'Combined')
      this.showCombined = true;
    $(".sa_tab_btn").removeClass('active');
    $("."+chart).addClass('active');
  }

  // Filter By Date
  filterDate(duration) {
     $('.customRange').css('display','none');

    if(duration == 'w') {
      const now = new Date();
       var first = now.getDate() - now.getDay();
       var last = first +6; 
       this.startDate = this.datePipe.transform(new Date(now.setDate(first)).toUTCString(), 'yyyy-MM-dd');
       this.endDate = this.datePipe.transform(new Date(now.setDate(last)).toUTCString(), 'yyyy-MM-dd');
    this.loadDentist('all');


    }
    else if (duration == 'm') {
      var date = new Date();
      this.startDate = this.datePipe.transform(new Date(date.getFullYear(), date.getMonth(), 1), 'yyyy-MM-dd');
      this.endDate = this.datePipe.transform(new Date(date.getFullYear(), date.getMonth() + 1, 0), 'yyyy-MM-dd');
    this.loadDentist('all');
   
    }
    else if (duration == 'q') {
      const now = new Date();
      var cmonth = now.getMonth();
      var cyear = now.getFullYear();
     
      if(cmonth >=1 && cmonth <=3) {
        this.startDate = this.datePipe.transform(new Date(now.getFullYear(), 0, 1), 'yyyy-MM-dd');
        this.endDate = this.datePipe.transform(new Date(now.getFullYear(), 3, 0), 'yyyy-MM-dd');
      }
      else if(cmonth >=4 && cmonth <=6) {
        this.startDate = this.datePipe.transform(new Date(now.getFullYear(), 3, 1), 'yyyy-MM-dd');
        this.endDate = this.datePipe.transform(new Date(now.getFullYear(), 6, 0), 'yyyy-MM-dd'); }
      else if(cmonth >=7 && cmonth <=9) {
        this.startDate = this.datePipe.transform(new Date(now.getFullYear(), 6, 1), 'yyyy-MM-dd');
        this.endDate = this.datePipe.transform(new Date(now.getFullYear(), 9, 0), 'yyyy-MM-dd'); }
      else if(cmonth >=10 && cmonth <=12) {1
        this.startDate = this.datePipe.transform(new Date(now.getFullYear(), 9, 1), 'yyyy-MM-dd');
        this.endDate = this.datePipe.transform(new Date(now.getFullYear(), 12, 0), 'yyyy-MM-dd');  }
    this.loadDentist('all');
    
    }
    else if (duration == 'lq') {
      const now = new Date();
      var cmonth = now.getMonth();
      var cyear = now.getFullYear();
     
      if(cmonth >=1 && cmonth <=3) {
        this.startDate = this.datePipe.transform(new Date(now.getFullYear() -1, 9, 1), 'yyyy-MM-dd');
        this.endDate = this.datePipe.transform(new Date(now.getFullYear()-1, 12, 0), 'yyyy-MM-dd');
      }
      else if(cmonth >=4 && cmonth <=6) {
        this.startDate = this.datePipe.transform(new Date(now.getFullYear(), 0, 1), 'yyyy-MM-dd');
        this.endDate = this.datePipe.transform(new Date(now.getFullYear(), 3, 0), 'yyyy-MM-dd'); }
      else if(cmonth >=7 && cmonth <=9) {
        this.startDate = this.datePipe.transform(new Date(now.getFullYear(), 3, 1), 'yyyy-MM-dd');
        this.endDate = this.datePipe.transform(new Date(now.getFullYear(), 6, 0), 'yyyy-MM-dd'); }
      else if(cmonth >=10 && cmonth <=12) {
        this.startDate = this.datePipe.transform(new Date(now.getFullYear(), 6, 1), 'yyyy-MM-dd');
        this.endDate = this.datePipe.transform(new Date(now.getFullYear(), 9, 0), 'yyyy-MM-dd');  }
    this.loadDentist('all');
   
    }
    else if (duration == 'cytd') {
     var date = new Date();
      this.startDate = this.datePipe.transform(new Date(date.getFullYear(), 0, 1), 'yyyy-MM-dd');
      this.endDate = this.datePipe.transform(new Date(), 'yyyy-MM-dd');
      this.loadDentist('all');
    }
     else if (duration == 'fytd') {
     var date = new Date();
      this.startDate = this.datePipe.transform(new Date(date.getFullYear(), 3, 1), 'yyyy-MM-dd');
      this.endDate = this.datePipe.transform(new Date(), 'yyyy-MM-dd');

      this.loadDentist('all');
    }
     else if (duration == 'custom') {
     $('.customRange').css('display','block');
    }
    $('.filter').removeClass('active');
    $('.filter_'+duration).addClass("active");
      $('.filter_custom').val(this.startDate+ " - "+this.endDate);

  }

  // Get Dentist
    getDentists() {
      this.dentistService.getDentists(this.clinic_id).subscribe((res) => {
           if(res.message == 'success'){
              this.dentists= res.data;
              this.dentistCount= res.data.length;

           }
        }, error => {
          this.warningMessage = "Please Provide Valid Inputs!";
        }    
        );
  }
  changeDentistPredictor(val){
    if(val =='1') {
       this.gaugeValuePredicted= this.gaugeValuePredicted1*100;
           this.predictedDentistTotal = this.gaugeValuePredicted1;

     }
    else if(val =='2'){
       this.gaugeValuePredicted= this.gaugeValuePredicted2*100;
           this.predictedDentistTotal = this.gaugeValuePredicted2;

     }
    else if(val =='3') {
       this.gaugeValuePredicted= this.gaugeValuePredicted3*100;  
           this.predictedDentistTotal = this.gaugeValuePredicted3;

     }
  } 
  ytd_load(val) {
    alert(this.datePipe.transform(val, 'yyyy-MM-dd'));
  }
choosedDate(val) {
    val = (val.chosenLabel);
    var val= val.toString().split(' - ');
      this.startDate = this.datePipe.transform(val[0], 'yyyy-MM-dd');
      this.endDate = this.datePipe.transform(val[1], 'yyyy-MM-dd');
      this.loadDentist('all');
      
      $('.filter_custom').val(this.startDate+ " - "+this.endDate);
     $('.customRange').css('display','none');
}
toggleFilter(val) {
    $('.filter').removeClass('active');
  
    if(val == 'current') {
      var date = new Date();
       this.startDate = this.datePipe.transform(new Date(date.getFullYear(), 0, 1), 'yyyy-MM-dd');
      this.endDate =this.datePipe.transform(new Date(date.getFullYear(), 12, 0), 'yyyy-MM-dd');
      this.loadDentist('all'); 
  }
  else if(val == 'historic') {
      var date = new Date();
       this.startDate = '';
      this.endDate ='';
      this.loadDentist('all'); 
  }
  else if(val == 'off') {
       this.filterDate('m');
  }
}

}
