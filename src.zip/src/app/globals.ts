import { Injectable } from '@angular/core';

@Injectable()
export class Globals {
  api_url: string = 'http://localhost/jeeveanalytics/server/';
  
}