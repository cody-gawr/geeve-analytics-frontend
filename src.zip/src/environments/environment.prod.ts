export const environment = {
  production: true,
  apiUrl : "http://localhost/jeeveanalytics/server",
  homeUrl:"http://localhost/jeeveanalytics/client2"
};
